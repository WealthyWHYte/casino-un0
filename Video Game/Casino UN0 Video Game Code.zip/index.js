
// casino-uno-mvp/backend/index.js

import express from 'express';
import cors from 'cors';
import GameEngine from './gameEngine.js';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// In-memory storage for game states and player ranks (for MVP)
const activeGames = {}; // gameId: GameEngine instance
export const playerRanks = {}; // playerId: ELO rank

// Helper to get or initialize player rank
const getPlayerRank = (playerId) => {
    if (!playerRanks[playerId]) {
        playerRanks[playerId] = 1000; // Default ELO rank
    }
    return playerRanks[playerId];
};

// API to start a new game
app.post('/api/game/start', (req, res) => {
    const { playerNames, ruleSet, mode } = req.body;
    if (!playerNames || playerNames.length < 2) {
        return res.status(400).json({ error: 'At least two players are required.' });
    }

    const gameEngine = new GameEngine(ruleSet);
    const initialState = gameEngine.initializeGame(playerNames);
    gameEngine.gameState.mode = mode; // Set mode from request
    activeGames[gameEngine.gameId] = gameEngine;

    res.json({ gameId: gameEngine.gameId, gameState: initialState });
});

// API to get current game state
app.get('/api/game/:gameId', (req, res) => {
    const { gameId } = req.params;
    const gameEngine = activeGames[gameId];

    if (!gameEngine) {
        return res.status(404).json({ error: 'Game not found.' });
    }
    res.json({ gameState: gameEngine.getGameState() });
});

// API to play a card
app.post('/api/game/:gameId/play', (req, res) => {
    const { gameId } = req.params;
    const { playerIndex, cardIndex, chosenColor } = req.body;
    const gameEngine = activeGames[gameId];

    if (!gameEngine) {
        return res.status(404).json({ error: 'Game not found.' });
    }

    try {
        const updatedState = gameEngine.playCard(playerIndex, cardIndex, chosenColor);
        if (updatedState.isGameOver) {
            const winnerIndex = updatedState.winner;
            const loserIndices = updatedState.players.map((_, i) => i).filter(i => i !== winnerIndex);

            // Update ELO ranks (simplified for MVP)
            const rankChanges = gameEngine.updateElo(winnerIndex, playerRanks);
            updatedState.players.forEach((player, index) => {
                const playerId = player.name; // Using name as a simple ID for MVP
                playerRanks[playerId] = (playerRanks[playerId] || 1000) + (rankChanges[index] || 0);
            });

            // Store match log (simplified: just log to console for MVP)
            console.log(`Game ${gameId} Over. Winner: ${updatedState.players[winnerIndex].name}`);
            console.log('Match Log:', gameEngine.getMatchLog());
            // In a real app, save match log to file/DB
        }
        res.json({ gameState: updatedState });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// API to draw a card
app.post('/api/game/:gameId/draw', (req, res) => {
    const { gameId } = req.params;
    const { playerIndex } = req.body;
    const gameEngine = activeGames[gameId];

    if (!gameEngine) {
        return res.status(404).json({ error: 'Game not found.' });
    }

    try {
        const updatedState = gameEngine.drawCard(playerIndex);
        res.json({ gameState: updatedState });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// API for computer/AI to make a move
app.post('/api/game/:gameId/computer-move', (req, res) => {
    const { gameId } = req.params;
    const { playerIndex } = req.body;
    const gameEngine = activeGames[gameId];

    if (!gameEngine) {
        return res.status(404).json({ error: 'Game not found.' });
    }

    try {
        const updatedState = gameEngine.computerPlay(playerIndex);
        if (updatedState.isGameOver) {
            const winnerIndex = updatedState.winner;
            // Update ELO ranks
            const rankChanges = gameEngine.updateElo(winnerIndex, playerRanks);
            updatedState.players.forEach((player, index) => {
                const playerId = player.name;
                playerRanks[playerId] = (playerRanks[playerId] || 1000) + (rankChanges[index] || 0);
            });
            console.log(`Game ${gameId} Over. Winner: ${updatedState.players[winnerIndex].name}`);
            console.log('Match Log:', gameEngine.getMatchLog());
        }
        res.json({ gameState: updatedState });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// API to get player ranks
app.get('/api/ranks', (req, res) => {
    res.json({ playerRanks });
});

app.listen(PORT, () => {
    console.log(`Backend server running on http://localhost:${PORT}`);
});

