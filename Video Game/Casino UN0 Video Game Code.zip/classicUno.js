
// casino-uno-mvp/rules/classicUno.js

const classicUnoRules = {
    name: "Classic UN0",
    description: "Standard UNO rules for basic gameplay.",
    initialHandSize: 7,
    maxPlayers: 4,
    canBet: false, // Classic UNO does not involve betting
    // Card types and their actions
    cardTypes: {
        '0': { color: ['red', 'yellow', 'green', 'blue'] },
        '1': { color: ['red', 'yellow', 'green', 'blue'] },
        '2': { color: ['red', 'yellow', 'green', 'blue'] },
        '3': { color: ['red', 'yellow', 'green', 'blue'] },
        '4': { color: ['red', 'yellow', 'green', 'blue'] },
        '5': { color: ['red', 'yellow', 'green', 'blue'] },
        '6': { color: ['red', 'yellow', 'green', 'blue'] },
        '7': { color: ['red', 'yellow', 'green', 'blue'] },
        '8': { color: ['red', 'yellow', 'green', 'blue'] },
        '9': { color: ['red', 'yellow', 'green', 'blue'] },
        'Skip': { color: ['red', 'yellow', 'green', 'blue'], action: 'skip' },
        'Reverse': { color: ['red', 'yellow', 'green', 'blue'], action: 'reverse' },
        'Draw Two': { color: ['red', 'yellow', 'green', 'blue'], action: 'drawTwo' },
        'Wild': { color: ['any'], action: 'wild' },
        'Wild Draw Four': { color: ['any'], action: 'wildDrawFour' }
    },

    // Function to initialize the deck
    initializeDeck: () => {
        let deck = [];
        const colors = ['red', 'yellow', 'green', 'blue'];
        const numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        const specialCards = ['Skip', 'Reverse', 'Draw Two'];

        // Number cards (two of each 1-9 per color, one 0 per color)
        colors.forEach(color => {
            deck.push({ type: '0', color: color });
            numbers.slice(1).forEach(number => {
                deck.push({ type: number, color: color });
                deck.push({ type: number, color: color });
            });
            // Special cards (two of each per color)
            specialCards.forEach(type => {
                deck.push({ type: type, color: color });
                deck.push({ type: type, color: color });
            });
        });

        // Wild cards (four of each)
        for (let i = 0; i < 4; i++) {
            deck.push({ type: 'Wild', color: 'any' });
            deck.push({ type: 'Wild Draw Four', color: 'any' });
        }
        return deck;
    },

    // Function to check if a card can be played
    canPlayCard: (card, topDiscard, currentColor) => {
        if (!topDiscard) return true; // First card can always be played

        // Wild cards can always be played
        if (card.type === 'Wild' || card.type === 'Wild Draw Four') {
            return true;
        }

        // Match by color or type
        return card.color === currentColor || card.type === topDiscard.type;
    },

    // Function to apply card effects
    applyCardEffect: (game, card, playerIndex) => {
        const { type, color } = card;
        const numPlayers = game.players.length;
        let nextPlayerIndex = game.currentPlayerIndex;
        let direction = game.direction;
        let cardsToDraw = 0;
        let skipNext = false;
        let newColor = color;

        switch (type) {
            case 'Skip':
                skipNext = true;
                break;
            case 'Reverse':
                direction *= -1;
                break;
            case 'Draw Two':
                cardsToDraw = 2;
                skipNext = true;
                break;
            case 'Wild':
                // Color choice handled by UI/player
                break;
            case 'Wild Draw Four':
                cardsToDraw = 4;
                skipNext = true;
                // Color choice handled by UI/player
                break;
        }

        // Update game state based on effects
        game.direction = direction;
        game.currentColor = newColor;

        // Determine next player after effects
        if (skipNext) {
            nextPlayerIndex = (game.currentPlayerIndex + direction * 2 + numPlayers) % numPlayers;
        } else {
            nextPlayerIndex = (game.currentPlayerIndex + direction + numPlayers) % numPlayers;
        }

        // Handle drawing cards for the affected player
        if (cardsToDraw > 0) {
            const affectedPlayerIndex = (game.currentPlayerIndex + direction + numPlayers) % numPlayers;
            for (let i = 0; i < cardsToDraw; i++) {
                game.players[affectedPlayerIndex].hand.push(game.drawPile.pop());
            }
        }

        game.currentPlayerIndex = nextPlayerIndex;
        return game;
    },

    // Function to check for UNO call requirement
    checkUnoCall: (playerHandSize) => {
        return playerHandSize === 1;
    },

    // Function to determine if game is over
    isGameOver: (playerHands) => {
        return playerHands.some(hand => hand.length === 0);
    },

    // Function to calculate score (for a single round, if applicable)
    calculateScore: (playerHands) => {
        let scores = {};
        playerHands.forEach((hand, index) => {
            scores[index] = hand.reduce((sum, card) => {
                let value = 0;
                switch (card.type) {
                    case 'Draw Two':
                    case 'Skip':
                    case 'Reverse':
                        value = 20;
                        break;
                    case 'Wild':
                    case 'Wild Draw Four':
                        value = 50;
                        break;
                    default:
                        value = parseInt(card.type);
                }
                return sum + value;
            }, 0);
        });
        return scores;
    }
};

export default classicUnoRules;

