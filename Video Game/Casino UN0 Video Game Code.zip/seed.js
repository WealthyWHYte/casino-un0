
// casino-uno-mvp/backend/seed.js

import { playerRanks } from './index.js'; // Assuming playerRanks is exported for seeding

const seedData = () => {
    console.log("Seeding initial player ranks...");

    // Add some initial player ranks
    playerRanks["Alice"] = 1200;
    playerRanks["Bob"] = 1100;
    playerRanks["Charlie"] = 950;
    playerRanks["David"] = 1050;

    console.log("Player ranks seeded:", playerRanks);

    // In a more complex scenario, you might simulate game plays here
    // to generate initial match logs, but for in-memory MVP, this is sufficient.
    console.log("Seeding complete.");
};

seedData();

