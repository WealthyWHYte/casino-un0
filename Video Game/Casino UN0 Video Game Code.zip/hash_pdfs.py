
import hashlib
import os

def hash_file(filepath):
    hasher = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while True:
            chunk = f.read(4096)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()

output_file = 'ip_document_hashes.md'

# List of PDF files to hash
pdf_files = [
    '/home/ubuntu/patent_application_uno_casino_gaming.pdf',
    '/home/ubuntu/copyright_registration_uno_casino_gaming.pdf',
    '/home/ubuntu/trademark_application_uno_casino_gaming.pdf',
    '/home/ubuntu/trade_secret_documentation_uno_casino_gaming.pdf',
    '/home/ubuntu/invention_disclosure_statement_uno_casino_gaming.pdf',
    '/home/ubuntu/prior_art_declaration_uno_casino_gaming.pdf',
    '/home/ubuntu/licensing_agreement_template_uno_casino_gaming.pdf'
]

with open(output_file, 'w') as outfile:
    outfile.write('# UNO Casino Gaming IP Document Hashes (SHA256)\n\n')
    outfile.write('This document records the SHA256 hashes of key Intellectual Property documents for UNO Casino Gaming, intended for blockchain deployment.\n\n')
    outfile.write('| Document Name | File Path | SHA256 Hash |\n')
    outfile.write('|---|---|---|\n')
    for filepath in pdf_files:
        if os.path.exists(filepath):
            file_hash = hash_file(filepath)
            document_name = os.path.basename(filepath).replace('.pdf', '').replace('_', ' ').title()
            outfile.write(f'| {document_name} | {filepath} | {file_hash} |\n')
        else:
            outfile.write(f'| {os.path.basename(filepath)} | {filepath} | File Not Found |\n')

print(f'Hashes written to {output_file}')

