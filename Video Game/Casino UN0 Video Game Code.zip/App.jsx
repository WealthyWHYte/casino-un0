import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Gamepad2, Users, Trophy, Play, Shuffle, Hand } from 'lucide-react'
import './App.css'

const API_BASE = 'http://localhost:3001/api'

function App() {
  const [gameState, setGameState] = useState(null)
  const [gameId, setGameId] = useState(null)
  const [playerName, setPlayerName] = useState('Player 1')
  const [selectedCard, setSelectedCard] = useState(null)
  const [chosenColor, setChosenColor] = useState(null)
  const [gameMode, setGameMode] = useState('Practice vs Computer')
  const [ruleSet, setRuleSet] = useState('Classic UN0')
  const [playerRanks, setPlayerRanks] = useState({})
  const [isLoading, setIsLoading] = useState(false)

  // Fetch player ranks on component mount
  useEffect(() => {
    fetchPlayerRanks()
  }, [])

  const fetchPlayerRanks = async () => {
    try {
      const response = await fetch(`${API_BASE}/ranks`)
      const data = await response.json()
      setPlayerRanks(data.playerRanks)
    } catch (error) {
      console.error('Error fetching ranks:', error)
    }
  }

  const startNewGame = async () => {
    setIsLoading(true)
    try {
      const playerNames = gameMode === 'Practice vs Computer' 
        ? [playerName, 'Computer'] 
        : [playerName, 'Dealer']
      
      const response = await fetch(`${API_BASE}/game/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerNames, ruleSet, mode: gameMode })
      })
      
      const data = await response.json()
      setGameId(data.gameId)
      setGameState(data.gameState)
      setSelectedCard(null)
      setChosenColor(null)
    } catch (error) {
      console.error('Error starting game:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const playCard = async (cardIndex) => {
    if (!gameId || gameState.currentPlayerIndex !== 0) return
    
    try {
      const response = await fetch(`${API_BASE}/game/${gameId}/play`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          playerIndex: 0, 
          cardIndex, 
          chosenColor: chosenColor 
        })
      })
      
      const data = await response.json()
      if (data.error) {
        alert(data.error)
        return
      }
      
      setGameState(data.gameState)
      setSelectedCard(null)
      setChosenColor(null)
      
      // If game is not over and it's computer's turn, make computer move
      if (!data.gameState.isGameOver && data.gameState.currentPlayerIndex === 1) {
        setTimeout(() => makeComputerMove(), 1000)
      }
      
      if (data.gameState.isGameOver) {
        fetchPlayerRanks()
      }
    } catch (error) {
      console.error('Error playing card:', error)
    }
  }

  const drawCard = async () => {
    if (!gameId || gameState.currentPlayerIndex !== 0) return
    
    try {
      const response = await fetch(`${API_BASE}/game/${gameId}/draw`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerIndex: 0 })
      })
      
      const data = await response.json()
      setGameState(data.gameState)
    } catch (error) {
      console.error('Error drawing card:', error)
    }
  }

  const makeComputerMove = async () => {
    if (!gameId) return
    
    try {
      const response = await fetch(`${API_BASE}/game/${gameId}/computer-move`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerIndex: 1 })
      })
      
      const data = await response.json()
      setGameState(data.gameState)
      
      if (data.gameState.isGameOver) {
        fetchPlayerRanks()
      }
    } catch (error) {
      console.error('Error making computer move:', error)
    }
  }

  const getCardColor = (card) => {
    const colorMap = {
      red: 'bg-red-500 border-red-400',
      yellow: 'bg-yellow-500 border-yellow-400',
      green: 'bg-green-500 border-green-400',
      blue: 'bg-blue-500 border-blue-400',
      any: 'bg-gradient-to-br from-red-500 via-yellow-500 via-green-500 to-blue-500 border-purple-400'
    }
    return colorMap[card.color] || 'bg-gray-500 border-gray-400'
  }

  const GameCard = ({ card, index, isPlayable, onClick, isSelected }) => (
    <div
      className={`
        relative w-16 h-24 rounded-lg border-2 cursor-pointer transition-all duration-200
        ${getCardColor(card)}
        ${isPlayable ? 'hover:scale-105 hover:shadow-lg hover:shadow-neon' : 'opacity-50 cursor-not-allowed'}
        ${isSelected ? 'ring-2 ring-white shadow-lg shadow-neon scale-105' : ''}
      `}
      onClick={() => isPlayable && onClick(index)}
    >
      <div className="absolute inset-1 bg-white/90 rounded-md flex items-center justify-center">
        <span className="text-xs font-bold text-black text-center">
          {card.type}
        </span>
      </div>
    </div>
  )

  const ColorSelector = ({ onColorSelect }) => (
    <div className="flex gap-2 mt-4">
      <span className="text-white">Choose color:</span>
      {['red', 'yellow', 'green', 'blue'].map(color => (
        <button
          key={color}
          className={`w-8 h-8 rounded-full border-2 border-white hover:scale-110 transition-transform ${
            color === 'red' ? 'bg-red-500' :
            color === 'yellow' ? 'bg-yellow-500' :
            color === 'green' ? 'bg-green-500' :
            'bg-blue-500'
          }`}
          onClick={() => onColorSelect(color)}
        />
      ))}
    </div>
  )

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Neon styling additions */}
      <style jsx>{`
        .shadow-neon {
          box-shadow: 0 0 20px currentColor;
        }
        .text-neon {
          text-shadow: 0 0 10px currentColor;
        }
        .border-neon {
          border-color: currentColor;
          box-shadow: 0 0 10px currentColor;
        }
      `}</style>

      <div className="container mx-auto p-4">
        <header className="text-center mb-8">
          <h1 className="text-6xl font-bold mb-4 text-neon bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 to-blue-500 bg-clip-text text-transparent">
            Casino UN0
          </h1>
          <p className="text-xl text-gray-300">MVP Demo - Play with Demo Chips Only</p>
        </header>

        <Tabs defaultValue="game" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-900 border border-gray-700">
            <TabsTrigger value="game" className="data-[state=active]:bg-blue-600">
              <Gamepad2 className="w-4 h-4 mr-2" />
              Game
            </TabsTrigger>
            <TabsTrigger value="lobby" className="data-[state=active]:bg-green-600">
              <Users className="w-4 h-4 mr-2" />
              Lobby
            </TabsTrigger>
            <TabsTrigger value="ranks" className="data-[state=active]:bg-yellow-600">
              <Trophy className="w-4 h-4 mr-2" />
              Rankings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="game" className="mt-6">
            {!gameState ? (
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-2xl text-center text-blue-400">Start New Game</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Player Name</label>
                    <Input
                      value={playerName}
                      onChange={(e) => setPlayerName(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Enter your name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Game Mode</label>
                    <Select value={gameMode} onValueChange={setGameMode}>
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="Practice vs Computer">Practice vs Computer</SelectItem>
                        <SelectItem value="Practice vs Dealer">Practice vs Dealer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Rule Set</label>
                    <Select value={ruleSet} onValueChange={setRuleSet}>
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="Classic UN0">Classic UN0</SelectItem>
                        <SelectItem value="Casino UN0">Casino UN0</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button 
                    onClick={startNewGame} 
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isLoading ? 'Starting...' : 'Start Game'}
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {/* Game Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-gray-900 border-gray-700">
                    <CardContent className="p-4">
                      <div className="text-sm text-gray-400">Game ID</div>
                      <div className="font-mono text-xs">{gameId}</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-900 border-gray-700">
                    <CardContent className="p-4">
                      <div className="text-sm text-gray-400">Current Player</div>
                      <div className="font-bold">
                        {gameState.players[gameState.currentPlayerIndex]?.name}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-900 border-gray-700">
                    <CardContent className="p-4">
                      <div className="text-sm text-gray-400">Demo Chips</div>
                      <div className="font-bold text-green-400">
                        {gameState.players[0]?.demoChips || 0}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Game Over Message */}
                {gameState.isGameOver && (
                  <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500">
                    <CardContent className="p-6 text-center">
                      <h2 className="text-2xl font-bold mb-2">Game Over!</h2>
                      <p className="text-lg">
                        Winner: {gameState.players[gameState.winner]?.name}
                      </p>
                      <Button 
                        onClick={() => setGameState(null)} 
                        className="mt-4 bg-green-600 hover:bg-green-700"
                      >
                        Play Again
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {/* Opponent Hand */}
                <Card className="bg-gray-900 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {gameState.players[1]?.name} - {gameState.players[1]?.hand.length} cards
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-1">
                      {Array.from({ length: gameState.players[1]?.hand.length || 0 }).map((_, i) => (
                        <div key={i} className="w-12 h-18 bg-gray-700 border border-gray-600 rounded-lg" />
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Game Table */}
                <Card className="bg-gray-900 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex justify-center items-center gap-8">
                      {/* Draw Pile */}
                      <div className="text-center">
                        <div className="w-20 h-28 bg-gray-700 border-2 border-gray-600 rounded-lg mb-2 flex items-center justify-center">
                          <Shuffle className="w-8 h-8 text-gray-400" />
                        </div>
                        <div className="text-sm text-gray-400">Draw Pile</div>
                        <div className="text-xs">{gameState.drawPile?.length || 0} cards</div>
                      </div>

                      {/* Discard Pile */}
                      <div className="text-center">
                        {gameState.discardPile?.length > 0 && (
                          <GameCard 
                            card={gameState.discardPile[gameState.discardPile.length - 1]}
                            isPlayable={false}
                          />
                        )}
                        <div className="text-sm text-gray-400 mt-2">Discard Pile</div>
                        <div className="text-xs">Current Color: 
                          <span className={`ml-1 px-2 py-1 rounded text-xs ${
                            gameState.currentColor === 'red' ? 'bg-red-500' :
                            gameState.currentColor === 'yellow' ? 'bg-yellow-500' :
                            gameState.currentColor === 'green' ? 'bg-green-500' :
                            gameState.currentColor === 'blue' ? 'bg-blue-500' :
                            'bg-gray-500'
                          }`}>
                            {gameState.currentColor}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Player Hand */}
                <Card className="bg-gray-900 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>Your Hand ({gameState.players[0]?.hand.length} cards)</span>
                      {gameState.currentPlayerIndex === 0 && !gameState.isGameOver && (
                        <Badge className="bg-green-600">Your Turn</Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {gameState.players[0]?.hand.map((card, index) => {
                        const topDiscard = gameState.discardPile[gameState.discardPile.length - 1]
                        const isPlayable = gameState.currentPlayerIndex === 0 && 
                          !gameState.isGameOver &&
                          (card.type === 'Wild' || card.type === 'Wild Draw Four' || 
                           card.color === gameState.currentColor || 
                           card.type === topDiscard?.type)
                        
                        return (
                          <GameCard
                            key={index}
                            card={card}
                            index={index}
                            isPlayable={isPlayable}
                            isSelected={selectedCard === index}
                            onClick={(cardIndex) => {
                              if (card.type === 'Wild' || card.type === 'Wild Draw Four') {
                                setSelectedCard(cardIndex)
                              } else {
                                playCard(cardIndex)
                              }
                            }}
                          />
                        )
                      })}
                    </div>

                    {/* Wild Card Color Selection */}
                    {selectedCard !== null && 
                     (gameState.players[0]?.hand[selectedCard]?.type === 'Wild' || 
                      gameState.players[0]?.hand[selectedCard]?.type === 'Wild Draw Four') && (
                      <div className="border-t border-gray-700 pt-4">
                        <ColorSelector 
                          onColorSelect={(color) => {
                            setChosenColor(color)
                            playCard(selectedCard)
                          }}
                        />
                      </div>
                    )}

                    {/* Action Buttons */}
                    {gameState.currentPlayerIndex === 0 && !gameState.isGameOver && (
                      <div className="flex gap-2 mt-4">
                        <Button 
                          onClick={drawCard}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Hand className="w-4 h-4 mr-2" />
                          Draw Card
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="lobby" className="mt-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-center text-green-400">PvP Lobbies</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-12">
                <Users className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                <p className="text-xl text-gray-400 mb-4">Coming in Phase 2</p>
                <p className="text-gray-500">
                  Multiplayer lobbies will be available in the next phase of development.
                  For now, enjoy practicing against the computer or dealer!
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ranks" className="mt-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-center text-yellow-400">ELO Rankings</CardTitle>
              </CardHeader>
              <CardContent>
                {Object.keys(playerRanks).length > 0 ? (
                  <div className="space-y-2">
                    {Object.entries(playerRanks)
                      .sort(([,a], [,b]) => b - a)
                      .map(([player, rank], index) => (
                        <div key={player} className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Badge className={
                              index === 0 ? 'bg-yellow-600' :
                              index === 1 ? 'bg-gray-400' :
                              index === 2 ? 'bg-orange-600' :
                              'bg-gray-600'
                            }>
                              #{index + 1}
                            </Badge>
                            <span className="font-medium">{player}</span>
                          </div>
                          <span className="text-lg font-bold text-yellow-400">{rank}</span>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Trophy className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">No rankings yet. Play some games to see rankings!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App
