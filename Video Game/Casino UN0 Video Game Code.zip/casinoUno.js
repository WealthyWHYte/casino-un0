
// casino-uno-mvp/rules/casinoUno.js

import classicUnoRules from './classicUno';

const casinoUnoRules = {
    ...classicUnoRules,
    name: "Casino UN0",
    description: "UNO rules adapted for a casino environment, including betting.",
    canBet: true, // Casino UNO allows betting
    initialBetAmount: 100, // Example initial bet
    bettingRoundInterval: 3, // Example: betting round every 3 turns

    // Override or extend card types if Casino UNO has unique cards or actions
    cardTypes: {
        ...classicUnoRules.cardTypes,
        // Example: a special 'Jackpot' card or 'Double Down' card
        // 'Jackpot': { color: ['any'], action: 'jackpot' }
    },

    // Override initializeDeck if Casino UNO uses a different deck composition
    // For now, assume same deck as classic, but could add more decks or special cards

    // Extend applyCardEffect to include betting logic or other casino-specific effects
    applyCardEffect: (game, card, playerIndex) => {
        // Apply classic UNO effects first
        let updatedGame = classicUnoRules.applyCardEffect(game, card, playerIndex);

        // Add Casino UNO specific effects
        // Example: If a 'Jackpot' card was played, trigger jackpot logic
        // if (card.type === 'Jackpot') {
        //     updatedGame.pot += updatedGame.jackpotAmount; // Example
        // }

        // Handle betting rounds (simplified example)
        updatedGame.turnCount = (updatedGame.turnCount || 0) + 1;
        if (updatedGame.canBet && updatedGame.turnCount % updatedGame.bettingRoundInterval === 0) {
            // Trigger a betting round. This would typically involve UI interaction
            // For AI players, they would make a decision based on their hand strength
            console.log(`Betting round triggered after turn ${updatedGame.turnCount}`);
            // This is a placeholder. Actual betting logic would be more complex
            // and involve player inputs, pot management, etc.
        }

        return updatedGame;
    },

    // New function for betting logic (to be called by UI/AI)
    placeBet: (game, playerIndex, amount) => {
        if (!game.canBet) {
            console.log("Betting is not allowed in this ruleset.");
            return game;
        }
        if (game.players[playerIndex].demoChips < amount) {
            console.log("Not enough demo chips to place bet.");
            return game;
        }
        game.players[playerIndex].demoChips -= amount;
        game.pot = (game.pot || 0) + amount;
        console.log(`Player ${playerIndex} bet ${amount}. Pot is now ${game.pot}`);
        return game;
    },

    // Override calculateScore for casino-style payouts
    calculateScore: (playerHands, pot) => {
        let scores = classicUnoRules.calculateScore(playerHands);
        let winnerIndex = -1;
        let minScore = Infinity;

        // Find player with lowest score (UNO winner)
        for (const playerIndex in scores) {
            if (playerHands[playerIndex].length === 0) {
                winnerIndex = parseInt(playerIndex);
                break;
            }
            if (scores[playerIndex] < minScore) {
                minScore = scores[playerIndex];
                winnerIndex = parseInt(playerIndex);
            }
        }

        let payouts = {};
        if (winnerIndex !== -1) {
            // Winner takes the pot
            payouts[winnerIndex] = (pot || 0);
            // Optionally, other players lose their initial bet or score difference
            // This needs more detailed rules for casino payouts
        }
        return payouts; // Returns an object of playerIndex: payoutAmount
    },

    // Additional Casino UNO specific parameters or functions
    // For example, rules for side bets, progressive jackpots, etc.
};

export default casinoUnoRules;

