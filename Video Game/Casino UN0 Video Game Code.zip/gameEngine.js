
// casino-uno-mvp/backend/gameEngine.js

import * as ClassicUnoRules from "../rules/classicUno.js";
import * as CasinoUnoRules from "../rules/casinoUno.js";

class GameEngine {
    constructor(ruleSetName = "Classic UN0") {
        this.rules = this.loadRules(ruleSetName);
        this.gameState = {};
        this.matchLog = [];
        this.gameId = this.generateGameId();
    }

    loadRules(ruleSetName) {
        switch (ruleSetName) {
            case "Classic UN0":
                return ClassicUnoRules.default;
            case "Casino UN0":
                return CasinoUnoRules.default;
            default:
                console.warn(`Rule set '${ruleSetName}' not found. Loading Classic UN0.`);
                return ClassicUnoRules.default;
        }
    }

    generateGameId() {
        return `game_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // Initializes a new game state
    initializeGame(playerNames) {
        const deck = this.shuffleDeck(this.rules.initializeDeck());
        const players = playerNames.map(name => ({
            name,
            hand: [],
            demoChips: 1000, // Starting demo chips for all players
            hasCalledUno: false,
        }));

        // Deal initial hands
        for (let i = 0; i < this.rules.initialHandSize; i++) {
            players.forEach(player => {
                player.hand.push(deck.pop());
            });
        }

        const discardPile = [deck.pop()];
        let currentColor = discardPile[0].color === 'any' ? 'red' : discardPile[0].color; // Default wild to red

        this.gameState = {
            gameId: this.gameId,
            mode: "Practice vs Computer", // This will be set dynamically based on game mode
            players,
            drawPile: deck,
            discardPile,
            currentPlayerIndex: 0,
            direction: 1, // 1 for clockwise, -1 for counter-clockwise
            currentColor: currentColor,
            turnCount: 0,
            isGameOver: false,
            winner: null,
            metadata: {},
        };
        this.logAction("Game Initialized", { playerNames, ruleSet: this.rules.name });
        return this.gameState;
    }

    shuffleDeck(deck) {
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
        return deck;
    }

    drawCard(playerIndex, count = 1) {
        for (let i = 0; i < count; i++) {
            if (this.gameState.drawPile.length === 0) {
                this.reshuffleDiscardPile();
            }
            if (this.gameState.drawPile.length > 0) {
                const card = this.gameState.drawPile.pop();
                this.gameState.players[playerIndex].hand.push(card);
                this.logAction("Draw Card", { playerIndex, card });
            } else {
                console.warn("No cards left to draw!");
                this.gameState.isGameOver = true; // Or handle game end differently
                break;
            }
        }
        return this.gameState;
    }

    reshuffleDiscardPile() {
        const topCard = this.gameState.discardPile.pop(); // Keep top card
        let cardsToReshuffle = this.gameState.discardPile;
        this.gameState.drawPile = this.shuffleDeck(cardsToReshuffle);
        this.gameState.discardPile = [topCard];
        this.logAction("Reshuffle Discard Pile");
    }

    playCard(playerIndex, cardIndex, chosenColor = null) {
        const player = this.gameState.players[playerIndex];
        const card = player.hand[cardIndex];
        const topDiscard = this.gameState.discardPile[this.gameState.discardPile.length - 1];

        if (!this.rules.canPlayCard(card, topDiscard, this.gameState.currentColor)) {
            throw new Error("Invalid move: Card cannot be played.");
        }

        // Remove card from player's hand
        player.hand.splice(cardIndex, 1);
        this.gameState.discardPile.push(card);

        // Apply card effects
        this.gameState = this.rules.applyCardEffect(this.gameState, card, playerIndex);

        // Handle wild card color choice
        if ((card.type === 'Wild' || card.type === 'Wild Draw Four') && chosenColor) {
            this.gameState.currentColor = chosenColor;
        } else if (card.color !== 'any') {
            this.gameState.currentColor = card.color;
        }

        this.logAction("Play Card", { playerIndex, card, chosenColor });

        // Check for UNO call
        if (player.hand.length === 1 && !player.hasCalledUno) {
            // In a real game, this would require player input to call UNO
            // For AI, we can assume it calls UNO automatically
            this.logAction("UNO Call", { playerIndex });
            player.hasCalledUno = true;
        } else if (player.hand.length > 1) {
            player.hasCalledUno = false;
        }

        // Check for game over
        if (player.hand.length === 0) {
            this.gameState.isGameOver = true;
            this.gameState.winner = playerIndex;
            this.logAction("Game Over", { winner: playerIndex });
        }

        // Advance to next player (handled by applyCardEffect for skips/reverses)
        if (!this.gameState.isGameOver) {
            this.gameState.currentPlayerIndex = this.gameState.currentPlayerIndex;
            this.gameState.turnCount++;
        }

        return this.gameState;
    }

    passTurn(playerIndex) {
        // A player can only pass if they drew a card and couldn't play it
        // This logic needs to be managed by the UI/AI that calls this.
        // For now, simply advance to the next player.
        this.logAction("Pass Turn", { playerIndex });
        this.gameState.currentPlayerIndex = (this.gameState.currentPlayerIndex + this.gameState.direction + this.gameState.players.length) % this.gameState.players.length;
        this.gameState.turnCount++;
        return this.gameState;
    }

    // Basic AI for computer player
    computerPlay(playerIndex) {
        const player = this.gameState.players[playerIndex];
        const topDiscard = this.gameState.discardPile[this.gameState.discardPile.length - 1];
        const currentColor = this.gameState.currentColor;

        // Try to play a matching card
        for (let i = 0; i < player.hand.length; i++) {
            const card = player.hand[i];
            if (this.rules.canPlayCard(card, topDiscard, currentColor)) {
                let chosenColor = null;
                if (card.type === 'Wild' || card.type === 'Wild Draw Four') {
                    // For AI, choose the color that is most prevalent in its hand
                    const colorCounts = { red: 0, yellow: 0, green: 0, blue: 0 };
                    player.hand.forEach(c => {
                        if (c.color !== 'any') colorCounts[c.color]++;
                    });
                    chosenColor = Object.keys(colorCounts).reduce((a, b) => colorCounts[a] > colorCounts[b] ? a : b);
                }
                return this.playCard(playerIndex, i, chosenColor);
            }
        }

        // If no card can be played, draw a card
        this.drawCard(playerIndex);
        const newCardIndex = player.hand.length - 1;
        const newCard = player.hand[newCardIndex];

        // After drawing, check if the new card can be played
        if (this.rules.canPlayCard(newCard, topDiscard, currentColor)) {
            let chosenColor = null;
            if (newCard.type === 'Wild' || newCard.type === 'Wild Draw Four') {
                const colorCounts = { red: 0, yellow: 0, green: 0, blue: 0 };
                player.hand.forEach(c => {
                    if (c.color !== 'any') colorCounts[c.color]++;
                });
                chosenColor = Object.keys(colorCounts).reduce((a, b) => colorCounts[a] > colorCounts[b] ? a : b);
            }
            return this.playCard(playerIndex, newCardIndex, chosenColor);
        } else {
            // If new card cannot be played, pass turn
            return this.passTurn(playerIndex);
        }
    }

    logAction(type, details = {}) {
        this.matchLog.push({
            timestamp: Date.now(),
            turn: this.gameState.turnCount,
            currentPlayer: this.gameState.currentPlayerIndex,
            type,
            details,
            gameStateSnapshot: JSON.parse(JSON.stringify(this.gameState)) // Snapshot for replay/debug
        });
    }

    getMatchLog() {
        return this.matchLog;
    }

    getGameState() {
        return this.gameState;
    }

    // Placeholder for ELO ranking update logic
    updateElo(winnerIndex, playerRanks) {
        // This would be more complex, involving current ELOs and a calculation formula
        // For MVP, just a simple increment/decrement
        const rankChanges = {};
        this.gameState.players.forEach((_, index) => {
            if (index === winnerIndex) {
                rankChanges[index] = 12; // Example: winner gains 12 ELO
            } else {
                rankChanges[index] = -9; // Example: losers lose 9 ELO
            }
        });
        this.logAction("ELO Update", { winnerIndex, rankChanges });
        return rankChanges;
    }
}

export default GameEngine;

